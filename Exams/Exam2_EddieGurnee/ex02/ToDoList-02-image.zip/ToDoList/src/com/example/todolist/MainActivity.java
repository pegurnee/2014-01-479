package com.example.todolist;


import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivity extends Activity {
	
	private ListView lst_sensorListView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mSetupToDoList();
    	
    	/*Button addButton = (Button) findViewById(R.id.myButton);
    	addButton.setOnClickListener(new OnClickListener() {
    	
    		@Override
    		public void onClick(View view) {
    	    	EditText myTextField = (EditText) findViewById(R.id.myTextField);
    	    	myListData.add(myTextField.getText().toString());
    	    	myListDataAdapter.notifyDataSetChanged();
    		}
    	});*/
	}
	
	private void mSetupToDoList() {
		
		MyListViewCell list_data[] = new MyListViewCell[]   {
		            new MyListViewCell(R.drawable.christmas_decorations, "Bell"),
		            new MyListViewCell(R.drawable.christmas_letter, "Letter"),
		            new MyListViewCell(R.drawable.christmas_tree, "Tree"),
		            new MyListViewCell(R.drawable.present, "Present")
		        };
		       
		ToDoListAdapter adapter = new ToDoListAdapter(this, R.layout.list_row, list_data);

		lst_sensorListView = (ListView)findViewById(R.id.myList);
		lst_sensorListView.setAdapter(adapter);

        // Handle list item click -- return the NXT 12-digit address
		lst_sensorListView.setOnItemClickListener(new OnItemClickListener() {
            public void onItemClick(AdapterView<?> av, View v, int arg2, long arg3) {
            	// Do something later	
            }
        });
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	// adapter fill data as array
	private class ToDoListAdapter extends ArrayAdapter<MyListViewCell>{
	    Context context;
	    int layoutResourceId;
	    MyListViewCell data[] = null;
	   
	    public ToDoListAdapter(Context context, int layoutResourceId, MyListViewCell[] data) {
	        super(context, layoutResourceId, data);
	        this.layoutResourceId = layoutResourceId;
	        this.context = context;
	        this.data = data;
	    }

	    @Override
	    public View getView(int position, View convertView, ViewGroup parent) {
	        View row = convertView;
	        MyListViewCellHolder holder = null;
	       
	        if(row == null) {
	            LayoutInflater inflater = ((Activity)context).getLayoutInflater();
	            row = inflater.inflate(layoutResourceId, parent, false);
	           
	            holder = new MyListViewCellHolder();
	            holder.imgIcon = (ImageView)row.findViewById(R.id.list_row_image);
	            holder.txtTitle = (TextView)row.findViewById(R.id.list_row_text);
	           
	            row.setTag(holder);
	        }
	        else  {
	            holder = (MyListViewCellHolder)row.getTag();
	        }
	       
	        MyListViewCell sensor = data[position];
	        holder.txtTitle.setText(sensor.getTitle());
	        holder.imgIcon.setImageResource(sensor.getIcon());
	       
	        return row;
	    }
	   
	    private class MyListViewCellHolder {
	        ImageView imgIcon;
	        TextView txtTitle;
	    }
	}
	
	// use a class as wrapper to hold data, so can be passed as array
	private class MyListViewCell {
		private int icon;
	    private String title;
	    	   
	    public MyListViewCell(int icon, String title) {
	        super();
	        this.icon = icon;
	        this.title = title;
	    }
	    
	    public int getIcon(){
	    	return icon;
	    }
	    
	    public String getTitle() {
	    	return title;
	    }
	}
}
