/** Automatically generated file. DO NOT MODIFY */
package com.commonsware.android.constants;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}